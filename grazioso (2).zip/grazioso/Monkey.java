
public class Monkey extends RescueAnimal {
	private String species;
	private String tailLength;
	private String height;
	private String bodyLength;
	
	//Default constructor
	/*public void Monkey() {
		species = "none";
		tailLength = "none";
		height = "none";
		bodyLength = "none";
	}*/
	
	//Full constructor
	public Monkey(String monkeyName, String monkeySpecies, String lengthOfTail, String monkeyHeight, String lengthOfBody, String gender, String age, String weight, String acquisitionDate, String acquisitionCountry, String trainingStatus, boolean reserved, String inServiceCountry) {
		setName(monkeyName);
		setSpecies(monkeySpecies);
		setTailLength(lengthOfTail);
		setHeight(monkeyHeight);
		setBodyLength(lengthOfBody);
		setGender(gender);
		setAge(age);
		setWeight(weight);
		setAcquisitionDate(acquisitionDate);
		setAcquisitionLocation(acquisitionCountry);
		setTrainingStatus(trainingStatus);
		setReserved(reserved);
		setInServiceCountry(inServiceCountry);
	}
	
	//get/set species
	public void setSpecies(String monkeySpecies) {
		species = monkeySpecies;
	}
	
	public String getSpecies() {
		return species;
	}
	
	//get/set tailLength
	public void setTailLength(String lengthOfTail) {
		tailLength = lengthOfTail;
	}
	
	public String getTailLength() {
		return tailLength;
	}
	
	//get/set height
	public void setHeight(String monkeyHeight) {
		height = monkeyHeight;
	}
	
	public String getHeight() {
		return height;
	}
	
	//get/set bodyLength
	public void setBodyLength(String lengthOfBody) {
		bodyLength = lengthOfBody;
	}
	
	public String getBodyLength() {
		return bodyLength;
	}
	
	// toString override
	public String toString() {
		return this.name + ", " + this.species + ", " + this.tailLength + ", " + this.height + ", " + this.bodyLength + ", " + this.gender + ", " + this.age + ", " + this.weight + ", " + this.acquisitionDate + ", " + this.acquisitionCountry + ", " + this.trainingStatus + ", " + this.reserved + ", " + this.inServiceCountry;
	}

}
