import java.util.ArrayList;
import java.util.Scanner;

public class Driver {
    private static ArrayList<Dog> dogList = new ArrayList<Dog>();
    // Instance variables (if needed)
    
    // added monkeyList
    private static ArrayList<Monkey> monkeyList = new ArrayList<Monkey>();

    public static void main(String[] args) {
    	Scanner scnr = new Scanner(System.in);
    	String userInput = " ";
    	displayMenu();
    	initializeDogList();
    	initializeMonkeyList();
    	userInput = scnr.nextLine();
    	
    	if (userInput.equalsIgnoreCase("q")) {
    		System.out.println("Application successfully terminated. Goodbye.");
    	}
    	// Menu loop and validation
    	while (!userInput.equals("q")) {
    		switch (userInput) {
    		case "1":
    			intakeNewDog(scnr);
    			break;
    		case "2":
    			intakeNewMonkey(scnr);
    			break;
    		case "3":
    			reserveAnimal(scnr);
    			break;
    		case "4":
    			printAnimals(1);
    			break;
    		case "5":
    			printAnimals(2);
    			break;
    		case "6":
    			printAnimals(3);
    			break;
			default:
				System.out.println("Invalid option, try again.");
				
			
    		}
    	displayMenu();
    	userInput = scnr.nextLine();

    	}
    	
        

        // Add a loop that displays the menu, accepts the users input
        // and takes the appropriate action.
	// For the project submission you must also include input validation
        // and appropriate feedback to the user.
        // Hint: create a Scanner and pass it to the necessary
        // methods 
	// Hint: Menu options 4, 5, and 6 should all connect to the printAnimals() method.
       
    }

    // This method prints the menu options
    public static void displayMenu() {
        System.out.println("\n\n");
        System.out.println("\t\t\t\tRescue Animal System Menu");
        System.out.println("[1] Intake a new dog");
        System.out.println("[2] Intake a new monkey");
        System.out.println("[3] Reserve an animal");
        System.out.println("[4] Print a list of all dogs");
        System.out.println("[5] Print a list of all monkeys");
        System.out.println("[6] Print a list of all animals that are not reserved");
        System.out.println("[q] Quit application");
        System.out.println();
        System.out.println("Enter a menu selection");
    }


    // Adds dogs to a list for testing
    public static void initializeDogList() {
        Dog dog1 = new Dog("Spot", "German Shepherd", "male", "1", "25.6", "05-12-2019", "United States", "in service", false, "Canada");
        Dog dog2 = new Dog("Rex", "Great Dane", "male", "3", "35.2", "02-03-2020", "United States", "in service", false, "Canada");
        Dog dog3 = new Dog("Bella", "Chihuahua", "female", "4", "25.6", "12-12-2019", "Canada", "in service", false, "Canada");

        dogList.add(dog1);
        dogList.add(dog2);
        dogList.add(dog3);
    }


    // Adds monkeys to a list for testing
    //Optional for testing
    public static void initializeMonkeyList() {
    	Monkey monkey1 = new Monkey("Chester", "Marmoset", "7", "8", "10", "male", "3", "8", "6-9-2020", "United States", "in service", false, "United States");
    	Monkey monkey2 = new Monkey("Lester", "Macaque", "9", "10", "13", "male", "5", "15", "4-20-2019", "Canada", "in service", false, "United States");
    	
    	monkeyList.add(monkey1);
    	monkeyList.add(monkey2);

    }


    // Complete the intakeNewDog method
    // The input validation to check that the dog is not already in the list
    // is done for you
    public static void intakeNewDog(Scanner scanner) {
        System.out.println("What is the dog's name?");
        String name = scanner.nextLine();
        for(Dog dog: dogList) {
            if(dog.getName().equalsIgnoreCase(name)) {
                System.out.println("\n\nThis dog is already in our system\n\n");
                return; //returns to menu
            }     	
           
        } 
        
        System.out.println("\nWhat is the breed of dog?");
        String breed = scanner.nextLine();
        
        System.out.println("\nWhat is the dog's gender?");
        String gender = scanner.nextLine();
        
        System.out.println("\nWhat is the dog's age in years?");
        String age = scanner.nextLine();
        
        System.out.println("\nEnter the dog's weight: ");
        String weight = scanner.nextLine();
        
        System.out.println("\nEnter the dog's acquisition date (mm-dd-yyyy): ");
        String acquisitionDate = scanner.nextLine();
        
        System.out.println("\nWhere was the dog acquired?");
        String acquisitionLocation = scanner.nextLine();
        
        System.out.println("\nWhat is the dog's training status?");
        String trainingStatus = scanner.nextLine();
        
        // Input validation for reserve status
        String tempVar = " ";
        boolean reserveStatus = false;
        while (!tempVar.equalsIgnoreCase("y") || !tempVar.equalsIgnoreCase("n")) {
            System.out.println("\nIs this dog currently reserved? Enter Y or N: ");
            tempVar = scanner.nextLine();
            if(tempVar.equalsIgnoreCase("y")) {
        	    reserveStatus = true;
        	    break;
            } else if (tempVar.equalsIgnoreCase("n")) {
        	    reserveStatus = false;
        	    break;
            } else {
        	    System.out.println("Invalid response");
        }
        }
        
        System.out.print("\nEnter the dog's country of service: ");
        String inServiceCountry = scanner.nextLine();
        
        Dog newDog = new Dog(name, breed, gender, age, weight, acquisitionDate, acquisitionLocation, trainingStatus, reserveStatus, inServiceCountry);
        dogList.add(newDog);
        return;
    }
 


        // intakeNewMonkey including input validation
        public static void intakeNewMonkey(Scanner scanner) {
        	
            System.out.println("\nEnter the monkey's name: ");
            String name = scanner.nextLine();
            
            String species = "none";
            boolean isValidSpecies = false;
            while (isValidSpecies == false) {
            	System.out.println("\nEnter the monkey's species (valid species are capuchin, guenon, macaque, marmoset, squirrel monkey, or tamarin): ");
                species = scanner.nextLine();
                
                if (species.equalsIgnoreCase("capuchin") || species.equalsIgnoreCase("guenon") || species.equalsIgnoreCase("macaque") || species.equalsIgnoreCase("marmoset") || species.equalsIgnoreCase("squirrel monkey") || species.equalsIgnoreCase("tamarin")) {
                	isValidSpecies = true;
                } else {
                	System.out.println("Invalid species type. Try again.");
                }
            }
            
            for (Monkey monkey: monkeyList) {
            	if (monkey.getName().equalsIgnoreCase(name) && monkey.getSpecies().equalsIgnoreCase(species)) {
            		System.out.println("\n\nThis monkey is already in our system.\n\n");
            		return;
            	}
            }
            
            System.out.println("\nEnter the length of the monkey's tail: ");
            String tailLength = scanner.nextLine();
            
            System.out.println("\nEnter the monkey's height: ");
            String height = scanner.nextLine();
            
            System.out.println("\nEnter the length of the monkey's body: ");
            String bodyLength = scanner.nextLine();
            
            System.out.println("\nEnter the monkey's gender: ");
            String gender = scanner.nextLine();
            
            System.out.println("\nEnter the monkey's age: ");
            String age = scanner.nextLine();
            
            System.out.println("\nEnter the monkey's weight: ");
            String weight = scanner.nextLine();
            
            System.out.println("\nEnter the monkey's acquisition date: ");
            String acquisitionDate = scanner.nextLine();
            
            System.out.println("\nEnter the monkey's acquisition location: ");
            String acquisitionCountry = scanner.nextLine();
            
            System.out.println("\nEnter the monkey's training status: ");
            String trainingStatus = scanner.nextLine();
            
            // input validation for reserve status
            String tempVar = " ";
            boolean reserved = false;
            while (!tempVar.equalsIgnoreCase("y") || !tempVar.equalsIgnoreCase("n")) {
                System.out.println("\nIs the monkey currently reserved? Enter Y or N: ");
                tempVar = scanner.nextLine();

                if (tempVar.equalsIgnoreCase("y")) {
            	    reserved = true;
            	    break;
                } else if (tempVar.equalsIgnoreCase("n")) {
            	    reserved = false;
            	    break;
                } else {
            	    System.out.println("Invalid response.");
            	
                }
            }
            
            System.out.println("\nEnter the monkey's country of service: ");
            String inServiceCountry = scanner.nextLine();
            
            Monkey newMonkey = new Monkey(name, species, tailLength, height, bodyLength, gender, age, weight, acquisitionDate, acquisitionCountry, trainingStatus, reserved, inServiceCountry);
            monkeyList.add(newMonkey);
            return;
        }

        // Complete reserveAnimal
        // You will need to find the animal by animal type and in service country
        public static void reserveAnimal(Scanner scanner) {
            System.out.println("Enter type of animal desired (dog or monkey): ");
            String animalType = scanner.nextLine();
            
            System.out.println("Enter country: ");
            String inServiceCountry = scanner.nextLine();
            
            if (animalType.equalsIgnoreCase("dog")) {
            	for (Dog dog: dogList) {
            		if(dog.getReserved() == false && dog.getInServiceLocation().equalsIgnoreCase(inServiceCountry)) {
            			dog.setReserved(true);
        				System.out.println(dog.getName() + " is now reserved.");
            			break;
            			}
            		
            		}
           
            } else if (animalType.equalsIgnoreCase("monkey")) {
            	for (Monkey monkey: monkeyList) {
            		if(monkey.getReserved() == false && monkey.getInServiceLocation().equalsIgnoreCase(inServiceCountry)) {
            			monkey.setReserved(true);
            			System.out.println(monkey.getName() + " is now reserved.");
            			break;
            		}
            	}
            }

        }

        // printAnimals
        public static void printAnimals(int listType) {
        	// print dogs
        	if (listType == 1) {
        		for (Dog dog: dogList) {
        			System.out.println(dog.toString());
        		}
        	}
        	// print monkeys
        	if (listType == 2) {
        		for (Monkey monkey: monkeyList) {
        			System.out.println(monkey.toString());
        		}
        	}
        	// print all available animals
        	if (listType == 3) {
        		int dogsAvailable = 0;
        		int monkeysAvailable = 0;
        		for (Dog dog: dogList) {
        			if (dog.getTrainingStatus().equalsIgnoreCase("in service") && dog.getReserved() == false) {
        				System.out.println(dog);
        				++dogsAvailable;
        			}
        		}
        		if (dogsAvailable == 0) {
    				System.out.println("There are no dogs currently available.");
        		}
        		for (Monkey monkey: monkeyList) {
        			if (monkey.getTrainingStatus().equalsIgnoreCase("in service") && monkey.getReserved() == false) {
        				System.out.println(monkey);
        				++monkeysAvailable;
        			} 
        		}
        		if (monkeysAvailable == 0) {
    				System.out.println("There are no monkeys currently available.");
        		}
        	}

        	return;
        }
}

